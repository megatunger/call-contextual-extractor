from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    DEBUG: int = 0

    # Redis Configuration
    # Handles message queue and connection settings for Redis
    REDIS_HOST: str = "0.0.0.0"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0
    REDIS_AUDIO_QUEUE: str = "audio_queue"

    # Model Configuration
    # Speech recognition model settings and hardware acceleration
    WAVE2VEC_MODEL: str
    DEVICE: str = "cuda"

    # Language Model Configuration
    LANGUAGE_MODEL: str
    BEEM_SEARCH: int = 200

    # Gender Model
    GENDER_MODEL: str

    # Audio Configuration
    BATCH_SIZE: int = 5
    SAMPLING_RATE: int = 16000

    # Processing Configuration
    # Settings that affect processing behavior and performance
    SERVER_SLEEP: float = 0.001
    REDIS_AUDIO_QUEUE_RESPONSE_EXPIRE: int = 5

    # API/Client Configuration
    API_KEY: str
    # REDIS_AUDIO_QUEUE_INPUT_EXPIRE = CLIENT_MAX_TRIES * CLIENT_SLEEP
    REDIS_AUDIO_QUEUE_INPUT_EXPIRE: int = 2
    CLIENT_SLEEP: float = 0.05
    CLIENT_MAX_TRIES: int = 40

    # Sentry Configuration
    SENTRY_DSN: str = ""  # Empty string means Sentry is disabled
    SENTRY_ENVIRONMENT: str = "production"  # Default environment
    SENTRY_SEND_PII: bool = False  # Default to False for privacy/security

    # Cấu hình để đọc từ file .env
    model_config = SettingsConfigDict(
        env_file='.env', env_file_encoding='utf-8')


settings = Settings()
