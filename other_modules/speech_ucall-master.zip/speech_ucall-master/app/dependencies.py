from fastapi import HTTPException, Security, status
from fastapi.security import APIKeyHeader

from app.core.config import settings

api_key_header_scheme = APIKeyHeader(name="x-api-key", auto_error=False)


async def get_api_key_security(api_key: str = Security(api_key_header_scheme)):
    if api_key is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing API Key"
        )
    if api_key != settings.API_KEY:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Could not validate credentials"  # Hoặc "Invalid API Key"
        )
    return api_key
