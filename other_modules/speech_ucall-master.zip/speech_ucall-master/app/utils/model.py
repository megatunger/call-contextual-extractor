import kenlm
from pyctcdecode import Alphabet, BeamSearchDecoderCTC, LanguageModel
import torch
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor

from app.core.config import settings


class Wav2Vec2Model:
    def __init__(self, model_name: str = settings.WAVE2VEC_MODEL):
        # Tắt gradient để tối ưu bộ nhớ và tốc độ khi inference
        torch.set_grad_enabled(False)
        self.model_name = model_name
        self.device = settings.DEVICE if torch.cuda.is_available() else "cpu"

    def load_model(self):
        self.model = Wav2Vec2ForCTC.from_pretrained(self.model_name)
        # Chuyển model sang GPU/CPU tùy theo cấu hình
        self.model.to(self.device)

    def load_processor(self):
        self.processor = Wav2Vec2Processor.from_pretrained(self.model_name)


def get_wav2vec_model(model=False, processor=True):
    wav2vec_model = Wav2Vec2Model()
    if model:
        wav2vec_model.load_model()
    if processor:
        wav2vec_model.load_processor()
    return wav2vec_model


def get_decoder_ngram_model(tokenizer, ngram_lm_path):
    """Create CTC beam search decoder with n-gram language model
    Args:
        tokenizer: Tokenizer object with vocabulary
        ngram_lm_path: Path to KenLM language model file
    Returns:
        BeamSearchDecoderCTC decoder object
    """
    vocab_dict = tokenizer.get_vocab()
    sort_vocab = sorted((value, key) for (key, value) in vocab_dict.items())
    vocab = [x[1] for x in sort_vocab][:-2]
    vocab_list = vocab
    alphabet = Alphabet.build_alphabet(vocab_list)
    lm_model = kenlm.Model(ngram_lm_path)
    decoder = BeamSearchDecoderCTC(alphabet,
                                   language_model=LanguageModel(lm_model))
    return decoder
