import soundfile as sf
from scipy.signal import resample, resample_poly


def read_and_resample_audiofile(file):
    # Read audio file and return audio data with sampling frequency
    audio, samplerate = sf.read(file)

    # Resample audio to 16 kHz if needed
    if samplerate != 16_000:  # resample if not 16 kHz, currently only support mono file.
        if samplerate == 8_000:
            # For 8kHz audio: upsample by factor of 2 (8kHz -> 16kHz)
            audio = resample_poly(audio, 2, 1)
        elif samplerate == 48_000:
            # For 48kHz audio: downsample by factor of 3 (48kHz -> 16kHz)
            audio = resample_poly(audio, 1, 3)
        else:
            # For other sampling rates: resample to 16kHz using linear interpolation
            audio = resample(audio, round(audio.size * 16_000 / samplerate))
    return audio
