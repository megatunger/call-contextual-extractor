import os

import rpy2.robjects as robjects
import rpy2.robjects.packages as rpackages
from pydub.silence import detect_nonsilent
from rpy2.robjects.vectors import StrVector

os.environ['R_HOME'] = "/usr/lib/R"

# install R packages

# import R's utility package
utils = rpackages.importr('utils')
# select a mirror for R packages
utils.chooseCRANmirror(ind=1)  # select the first mirror in the list
packnames = ('tuneR', 'seewave', 'fftw')
names_to_install = [x for x in packnames if not rpackages.isinstalled(x)]
if len(names_to_install) > 0:
    utils.install_packages(StrVector(names_to_install))


robjects.r('''
library(tuneR)
library(seewave)

feature_extractor <- function(file_path, bp = c(0,22), wl = 2048, threshold = 5, parallel = 1, selec=0, start=0, end=20){
  # To use parallel processing: library(devtools), install_github('nathanvan/parallelsugar')

  #if there are NAs in start or end stop
  if(any(is.na(c(end, start)))) stop("NAs found in start and/or end")

  #if end or start are not numeric stop
  if(all(class(end) != "numeric" & class(start) != "numeric")) stop("'end' and 'selec' must be numeric")

  #if any start higher than end stop
  if(any(end - start<0)) stop(paste("The start is higher than the end in", length(which(end - start<0)), "case(s)"))

  #if any selections longer than 20 secs stop
  if(any(end - start>20)) stop(paste(length(which(end - start>20)), "selection(s) longer than 20 sec"))
  options( show.error.messages = TRUE)

  #if bp is not vector or length!=2 stop
  if(!is.vector(bp)) stop("'bp' must be a numeric vector of length 2") else{
    if(!length(bp) == 2) stop("'bp' must be a numeric vector of length 2")}

  # If parallel is not numeric
  if(!is.numeric(parallel)) stop("'parallel' must be a numeric vector of length 1")
  if(any(!(parallel %% 1 == 0),parallel < 1)) stop("'parallel' should be a positive integer")

  # If parallel was called
  # If parallel was called
  # if(parallel > 1)
  # { options(warn = -1)
  #   if(all(Sys.info()[1] == "Windows",requireNamespace("parallelsugar", quietly = TRUE) == TRUE))
  #     lapp <- function(X, FUN) parallelsugar::mclapply(X, FUN, mc.cores = parallel) else
  #       if(Sys.info()[1] == "Windows"){
  #         cat("Windows users need to install the 'parallelsugar' package for parallel computing (you are not doing it now!)")
  #         lapp <- pbapply::pblapply} else lapp <- function(X, FUN) parallel::mclapply(X, FUN, mc.cores = parallel)} else lapp <- pbapply::pblapply

  options(warn = 0)

  # if(parallel == 1) cat("Measuring acoustic parameters:")
  # x <- as.data.frame(lapp(1:length(start), function(i) {
    r <- tuneR::readWave(file_path, from = start, to = end, units = "seconds")

    b<- bp #in case bp its higher than can be due to sampling rate
    if(b[2] > ceiling(r@samp.rate/2000) - 1) b[2] <- ceiling(r@samp.rate/2000) - 1

    #frequency spectrum analysis
    songspec <- seewave::spec(r, f = r@samp.rate, plot = FALSE)
    analysis <- seewave::specprop(songspec, f = r@samp.rate, flim = c(0, 280/1000), plot = FALSE)

    #save parameters
    meanfreq <- analysis$mean/1000
    sd <- analysis$sd/1000
    median <- analysis$median/1000
    Q25 <- analysis$Q25/1000
    Q75 <- analysis$Q75/1000
    IQR <- analysis$IQR/1000
    skew <- analysis$skewness
    kurt <- analysis$kurtosis
    sp.ent <- analysis$sh
    sfm <- analysis$sfm
    mode <- analysis$mode/1000
    centroid <- analysis$cent/1000

    #Frequency with amplitude peaks
    # peakf <- 0#seewave::fpeaks(songspec, f = r@samp.rate, wl = wl, nmax = 3, plot = FALSE)[1, 1]

    #Fundamental frequency parameters
    ff <- seewave::fund(r, f = r@samp.rate, ovlp = 50, threshold = threshold,
                        fmax = 280, ylim=c(0, 280/1000), plot = FALSE, wl = wl)[, 2]
    meanfun<-mean(ff, na.rm = T)
    minfun<-min(ff, na.rm = T)
    maxfun<-max(ff, na.rm = T)

    #Dominant frecuency parameters
    y <- seewave::dfreq(r, f = r@samp.rate, wl = wl, ylim=c(0, 280/1000), ovlp = 0, plot = F, threshold = threshold, bandpass = b * 1000, fftw = TRUE)[, 2]
    meandom <- mean(y, na.rm = TRUE)
    mindom <- min(y, na.rm = TRUE)
    maxdom <- max(y, na.rm = TRUE)
    dfrange <- (maxdom - mindom)
    duration <- (end - start)

    #modulation index calculation
    changes <- vector()
    for(j in which(!is.na(y))){
      change <- abs(y[j] - y[j + 1])
      changes <- append(changes, change)
    }
    if(mindom==maxdom) modindx<-0 else modindx <- mean(changes, na.rm = T)/dfrange

    #save results
    return(c(meanfreq, sd, median, Q25, Q75, IQR, skew, kurt, sp.ent, sfm, mode,
             centroid, meanfun, minfun, maxfun, meandom, mindom, maxdom, dfrange, modindx))
  # }))

}
''')

feature_extractor = robjects.r['feature_extractor']


# length in ms
def get_nonsilence(audio, length=2000, silence_thresh=-16, min_accept_dB=-60):

    chunks = detect_nonsilent(
        audio,
        min_silence_len=500,
        silence_thresh=max(min_accept_dB, audio.dBFS + silence_thresh),
    )
    final_start = 0
    max_len = 0
    for start, stop in chunks:
        duration = stop - start
        if duration > max_len:
            max_len = duration
            final_start = start

    return audio[final_start:final_start + 2000]
