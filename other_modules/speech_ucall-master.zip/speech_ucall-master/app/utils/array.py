import struct

import numpy as np


def encode_array_nkey(k, a):
    """Encode array with a key into bytes format
    Args:
        k: Key string (36 bytes)
        a: Numpy array to encode
    Returns:
        Bytes containing key, shape and array data
    """
    if len(a.shape) < 2:
        a = np.expand_dims(a, axis=0)
    h, w = a.shape
    shape = struct.pack('>II', h, w)
    return bytes(k, 'ascii') + shape + a.astype(np.float32).tobytes()


def decode_array_nkey(encoded):
    """Decode bytes back to key and array
    Args:
        encoded: Bytes containing encoded key and array
    Returns:
        Tuple of (key string, numpy array)
    """
    k = encoded[:36].decode('ascii')
    h, w = struct.unpack('>II', encoded[36:44])
    a = np.frombuffer(encoded[44:], dtype=np.float32).reshape(h, w)
    return k, a


def encode_array(a):
    """Encode numpy array to bytes
    Args:
        a: Numpy array to encode
    Returns:
        Bytes containing array shape and data
    """
    if len(a.shape) < 2:
        a = np.expand_dims(a, axis=0)
    h, w = a.shape
    shape = struct.pack('>II', h, w)
    return shape + a.astype(np.float32).tobytes()


def decode_array(encoded):
    """Decode bytes back to numpy array
    Args:
        encoded: Bytes containing encoded array
    Returns:
        Numpy array
    """
    h, w = struct.unpack('>II', encoded[:8])
    a = np.frombuffer(encoded[8:], dtype=np.float32).reshape(h, w)
    return a
