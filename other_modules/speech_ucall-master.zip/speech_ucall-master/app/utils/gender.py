from pathlib import Path
from tempfile import NamedTemporaryFile

import numpy as np
from catboost import CatBoostClassifier
from pydub import AudioSegment

from app.core.config import settings

from .gender_recog import feature_extractor, get_nonsilence


def detect_gender(gender_model: CatBoostClassifier, audio_file):
    audio_file.file.seek(0)
    suffix = Path(audio_file.filename).suffix
    tmp = NamedTemporaryFile(suffix=suffix)
    # shutil.copyfileobj(audio_file.file, tmp)
    audio_segment = AudioSegment.from_wav(audio_file.file)
    audio_segment = get_nonsilence(audio_segment)
    audio_segment.export(tmp, format="wav")
    return gender_model.predict_proba(
        np.array(feature_extractor(str(tmp.name))), thread_count=1)[0]


def get_gender_model():
    gender_model = CatBoostClassifier()
    gender_model.load_model(settings.GENDER_MODEL)
    return gender_model
