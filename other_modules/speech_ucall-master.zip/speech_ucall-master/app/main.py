from fastapi import FastAPI

from app.core.config import settings
from app.routers import ping, recognize, sentry

if settings.SENTRY_DSN:
    import sentry_sdk
    from sentry_sdk.integrations.fastapi import FastApiIntegration

    # Initialize Sentry
    sentry_sdk.init(
        dsn=settings.SENTRY_DSN,
        integrations=[FastApiIntegration()],
        environment=settings.SENTRY_ENVIRONMENT,
        # Performance monitoring configuration
        traces_sample_rate=1.0,
        profiles_sample_rate=1.0,

        # Control PII data collection
        # Only enable in production for specific tracking needs
        # Be cautious with GDPR and data privacy regulations
        send_default_pii=settings.SENTRY_SEND_PII,
    )

app = FastAPI(
    title="Speech API",
    version="0.1.0",
)

app.include_router(ping.router)
app.include_router(recognize.router)
app.include_router(sentry.router)
