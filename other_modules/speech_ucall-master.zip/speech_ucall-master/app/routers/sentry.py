from fastapi import APIRouter

router = APIRouter(
    prefix="/sentry",
    tags=["sentry"],
)


@router.get("/debug")
async def trigger_error():
    division_by_zero = 1 / 0
    return {"message": "This will trigger a division by zero error."}
