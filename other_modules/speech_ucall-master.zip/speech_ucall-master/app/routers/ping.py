from fastapi import APIRouter, Depends

from app.dependencies import get_api_key_security  # Import dependency

router = APIRouter(
    prefix="/ping",
    tags=["ping"],
    # dependencies=[Depends(get_api_key_security)]
)


@router.get("/")
async def main():
    return "pong"
