from time import sleep

from app.core.config import settings
from app.utils import (decode_array_nkey, encode_array, get_redis_db,
                       get_wav2vec_model)


def start_recognize_process():
    # Initialize model and processor from pretrained model
    wave2vec_model = get_wav2vec_model(model=True, processor=True)
    print("Model loaded successfully")

    # Initialize Redis connection to manage queue and store results
    redis_db = get_redis_db()
    print("Redis connection established")

    # Infinite loop to process incoming audio
    while True:
        # Use Redis pipeline to perform multiple operations atomically
        with redis_db.pipeline() as pipe:
            # Get up to BATCH_SIZE audio from the queue head
            pipe.lrange(settings.REDIS_AUDIO_QUEUE, 0, settings.BATCH_SIZE - 1)
            # Remove processed audio from queue to avoid duplicate processing
            pipe.ltrim(settings.REDIS_AUDIO_QUEUE, settings.BATCH_SIZE, -1)
            queue, _ = pipe.execute()

        # Initialize lists to store audio and IDs for processing in current batch
        audio_ids = []  # Store IDs for mapping with results after processing
        audios = []     # Store normalized audio data

        for byte_encoded in queue:
            # Decode data from Redis: returns key and tensor containing audio data
            audio_id, audio = decode_array_nkey(byte_encoded)
            # Check task validity, skip if expired
            if redis_db.getdel(audio_id + '0') is None:
                continue
            # Remove redundant dimension and add to batch
            audios.append(audio.squeeze())
            audio_ids.append(audio_id)

        # Process batch if there's at least one valid audio
        if len(audio_ids) > 0:
            if settings.DEBUG:
                import timeit
                checkpoint_debug = timeit.default_timer()

            # Preprocess audio: normalize sampling rate and padding
            inputs = wave2vec_model.processor(
                audios,
                sampling_rate=settings.SAMPLING_RATE,
                return_tensors="pt",
                padding="longest")
            input_values = inputs.input_values.to(wave2vec_model.device)
            # Perform inference for speech recognition
            logits = wave2vec_model.model(input_values).logits

            if settings.DEBUG:
                print("* Batch size: {}, process time:{}".format(input_values.shape,
                      timeit.default_timer() - checkpoint_debug))

            # Save results to Redis with expiration
            # Each audio is stored with corresponding key for client retrieval
            for (audio_id, logit) in zip(audio_ids, logits):
                redis_db.set(
                    audio_id,
                    encode_array(logit.cpu().numpy()),
                    ex=settings.REDIS_AUDIO_QUEUE_RESPONSE_EXPIRE)

        # Pause to reduce CPU load and allow other processes to handle
        sleep(settings.SERVER_SLEEP)


if __name__ == "__main__":
    start_recognize_process()
