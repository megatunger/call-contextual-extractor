#!/bin/bash

DIR=/usr/src/speech_ucall
VENV=/usr/src/speech_venv/bin/activate

cd $DIR
source $VENV

exec python recognize_process.py
