(python3 -m venv /usr/src/speech_venv && 
source /usr/src/speech_venv/bin/activate &&
pip install -r requirements/production.txt --no-cache-dir)

(cp systemd_services/* /etc/systemd/system/ &&
systemctl daemon-reload &&
systemctl enable api.service model.service &&
systemctl start model &&
systemctl start api)

(sleep 60 &&
source /usr/src/speech_venv/bin/activate &&
python test_api.py)
