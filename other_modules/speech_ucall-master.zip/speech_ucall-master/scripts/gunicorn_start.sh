#!/bin/bash

DIR=/usr/src/speech_ucall
LOG_DIR=$DIR/logs
LOG_CONFIG=$DIR/scripts/logging.conf
VENV=/usr/src/speech_venv/bin/activate
NAME=speech
WORKERS=40
WORKER_CLASS=uvicorn.workers.UvicornWorker
BIND=0.0.0.0:8000

cd $DIR
source $VENV
mkdir -p $LOG_DIR

exec gunicorn app.main:app \
  --name $NAME \
  --workers $WORKERS \
  --worker-class $WORKER_CLASS \
  --bind=$BIND \
  --log-config $LOG_CONFIG \
  --preload
