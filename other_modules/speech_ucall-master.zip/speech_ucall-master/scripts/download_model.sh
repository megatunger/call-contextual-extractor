#!/bin/bash

mkdir -p /usr/src/model_cache
(cd /usr/src/model_cache &&
wget https://huggingface.co/nguyenvulebinh/wav2vec2-base-vietnamese-250h/resolve/main/vi_lm_4grams.bin.zip &&
unzip vi_lm_4grams.bin.zip &&
rm -f vi_lm_4grams.bin.zip)
(cd /usr/src/model_cache &&
wget https://huggingface.co/nguyenvulebinh/wav2vec2-base-vietnamese-250h/resolve/main/config.json &&
wget https://huggingface.co/nguyenvulebinh/wav2vec2-base-vietnamese-250h/resolve/main/preprocessor_config.json &&
wget https://huggingface.co/nguyenvulebinh/wav2vec2-base-vietnamese-250h/resolve/main/pytorch_model.bin &&
wget https://huggingface.co/nguyenvulebinh/wav2vec2-base-vietnamese-250h/resolve/main/tokenizer_config.json &&
wget https://huggingface.co/nguyenvulebinh/wav2vec2-base-vietnamese-250h/resolve/main/vocab.json)