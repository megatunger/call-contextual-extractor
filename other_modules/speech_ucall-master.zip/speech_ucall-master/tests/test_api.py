# import the necessary packages
import time
from threading import Thread
from timeit import default_timer

import requests

# initialize the API endpoint URL along with the input
api_url = 'http://127.0.0.1:8000/recognize'
AUDIO_PATH = 'sample_audio/a-chua-nghe-ro.wav'
api_key = "19aa3eaa-6486-442d-aeb7-2c080b5eb59c"
# initialize the number of requests for the stress test along with
# the sleep amount between requests
NUM_REQUESTS = 1
SLEEP_COUNT = 0.01


def call_predict_endpoint(n):
    # load the input image and construct the payload for the request
    audio_file = open(AUDIO_PATH, "rb")
    payload = {"audio_file": audio_file}
    start = default_timer()
    # submit the request
    res = requests.post(api_url, files=payload, headers={'X-API-key': api_key}, data={
                        "word_level": '1', 'confidence_score': '1', 'gender_recog': '1'})  # , data={"gender_recog": 'true'})
    print(res.json(), "delay:", default_timer() - start)


threads = []
# loop over the number of threads
for i in range(0, NUM_REQUESTS):
    # start a new thread to call the API
    t = Thread(target=call_predict_endpoint, args=(i,))
    t.daemon = True
    t.start()
    threads.append(t)
    time.sleep(SLEEP_COUNT)

for t in threads:
    t.join()
